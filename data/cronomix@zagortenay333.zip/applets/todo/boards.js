const _ME = imports.misc.extensionUtils.getCurrentExtension();

const St = imports.gi.St;
const { _ } = _ME.imports.utils.misc;
const { Card } = _ME.imports.utils.card;
const P = _ME.imports.utils.markup.parser;
const { show_info_popup } = _ME.imports.utils.popup;
const { Button, ButtonBox } = _ME.imports.utils.button;
const { compare_tasks } = _ME.imports.applets.todo.sort;
const { TaskCard } = _ME.imports.applets.todo.task;
const { ScrollBox, LazyScrollBox } = _ME.imports.utils.scroll;
var BoardView = class BoardView {
    actor;
    constructor(applet) {
        this.actor = new St.BoxLayout({ vertical: true, x_expand: true, style_class: 'cronomix-spacing' });
        //
        // Header
        //
        const header = new St.BoxLayout({});
        this.actor.add_actor(header);
        const add_task_button = new Button({ parent: header, style_class: 'bg', icon: 'cronomix-plus-symbolic', label: _('Add Task') });
        header.add_actor(new St.Widget({ x_expand: true, style: 'min-width: 20px;' }));
        const button_box = new ButtonBox(header);
        const search_button = button_box.add({ icon: 'cronomix-search-symbolic' });
        const sort_button = button_box.add({ icon: 'cronomix-sort-ascending-symbolic' });
        const boards_button = button_box.add({ icon: 'cronomix-filter-symbolic' });
        const files_button = button_box.add({ icon: 'cronomix-file-symbolic' });
        const storage_button = button_box.add({ icon: 'cronomix-wrench-symbolic' });
        //
        // columns
        //
        const columns_scroll = new ScrollBox(false);
        this.actor.add_actor(columns_scroll.actor);
        const board = applet.boards.get(applet.file.name_of_active_board ?? '');
        const columns = new Array();
        // Make columns:
        if (board) {
            for (const filter of board.board.filters) {
                const column = new Column(applet, filter, board.task.text);
                columns_scroll.box.add_actor(column.actor);
                columns.push(column);
            }
        }
        else {
            const text = '*';
            const parser = new P.Parser(text);
            const filter = parser.try_parse_filter();
            const column = new Column(applet, filter, text, false);
            columns_scroll.box.add_actor(column.actor);
            columns.push(column);
        }
        // Move tasks into corresponding columns:
        for (const task of applet.tasks) {
            for (const column of columns) {
                if (task.satisfies_filter(column.filter)) {
                    column.tasks.push(task);
                    break;
                }
            }
        }
        { // Sort and make task card widgets to the columns:
            const gen = function* (tasks) {
                for (const [, task] of tasks.entries()) {
                    const card = new TaskCard(applet, task);
                    yield card.actor;
                }
            };
            const sort = applet.storage.read.sort.value;
            for (const column of columns) {
                column.tasks.sort((a, b) => compare_tasks(sort, a, b));
                column.tasks_scroll.set_children(column.tasks.length, gen(column.tasks));
            }
        }
        //
        // listen
        //
        sort_button.subscribe('left_click', () => applet.show_sort_view());
        storage_button.subscribe('left_click', () => applet.show_settings());
        search_button.subscribe('left_click', () => applet.show_search_view());
        add_task_button.subscribe('left_click', () => applet.show_task_editor());
        boards_button.subscribe('left_click', () => applet.show_board_switcher());
        files_button.subscribe('left_click', () => applet.show_file_switcher());
    }
    destroy() {
        this.actor.destroy();
    }
}
class Column {
    filter;
    actor;
    tasks = new Array();
    tasks_scroll;
    constructor(applet, filter, filter_text, show_filter_header = true) {
        this.filter = filter;
        this.actor = new St.BoxLayout({ vertical: true, style_class: 'cronomix-spacing' });
        if (show_filter_header)
            new Button({ parent: this.actor, label: filter_text.substring(filter.start, filter.end) });
        this.tasks_scroll = new LazyScrollBox(applet.ext.storage.read.lazy_list_page_size.value);
        this.actor.add_actor(this.tasks_scroll.actor);
    }
}
var BoardSwitcher = class BoardSwitcher {
    actor;
    constructor(applet) {
        this.actor = new St.BoxLayout({ x_expand: true, vertical: true, style_class: 'cronomix-spacing' });
        if (applet.boards.size) {
            const cards_scroll = new ScrollBox();
            this.actor.add_actor(cards_scroll.actor);
            for (const [title, { board, task }] of applet.boards) {
                const card = new BoardCard(applet, board, task);
                if (title === applet.file.name_of_active_board) {
                    cards_scroll.box.insert_child_at_index(card.actor, 0);
                }
                else {
                    cards_scroll.box.add_actor(card.actor);
                }
            }
        }
        //
        // buttons
        //
        const help_msg = _('When you create boards in your todo file they will show up here.') + '\n' +
            _('In the task editor you can find information about how to add boards.');
        const button_box = new St.BoxLayout({ style_class: 'cronomix-spacing' });
        this.actor.add_actor(button_box);
        const button_close = new Button({ parent: button_box, wide: true, label: _('Close') });
        const button_help = new Button({ parent: button_box, icon: 'cronomix-question-symbolic' });
        button_close.subscribe('left_click', () => applet.show_board_view());
        button_help.subscribe('left_click', () => show_info_popup(button_help, help_msg));
    }
    destroy() {
        this.actor.destroy();
    }
}
class BoardCard extends Card {
    constructor(applet, board, task) {
        super();
        //
        // title
        //
        const msg = new St.Label({ text: board.title });
        this.left_header_box.add_actor(msg);
        //
        // buttons
        //
        const check_button = new Button({ icon: 'cronomix-todo-symbolic' });
        if (applet.file.name_of_active_board === board.title) {
            this.header.insert_child_above(check_button.actor, this.left_header_box);
        }
        else {
            this.autohide_box.add_actor(check_button.actor);
        }
        const edit_button = new Button({ parent: this.autohide_box, icon: 'cronomix-edit-symbolic' });
        //
        // listen
        //
        edit_button.subscribe('left_click', () => applet.show_task_editor(task));
        check_button.subscribe('left_click', () => {
            applet.file.name_of_active_board = board.title;
            applet.storage.flush();
            applet.show_board_view();
        });
    }
}
