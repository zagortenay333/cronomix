const _ME = imports.misc.extensionUtils.getCurrentExtension();

const St = imports.gi.St;
const Fs = _ME.imports.utils.fs;
const { Card } = _ME.imports.utils.card;
const M = _ME.imports.applets.todo.main;
const { ScrollBox } = _ME.imports.utils.scroll;
const { FilePicker } = _ME.imports.utils.pickers;
const { _, array_remove } = _ME.imports.utils.misc;
const { show_error_popup } = _ME.imports.utils.popup;
const { Button, ButtonBox, CheckBox } = _ME.imports.utils.button;
var FileSwitcher = class FileSwitcher {
    actor;
    #applet;
    #file_items_scroll;
    #button_box;
    #button_ok;
    #button_add_file;
    constructor(applet) {
        this.#applet = applet;
        this.actor = new St.BoxLayout({ x_expand: true, vertical: true, style_class: 'cronomix-spacing' });
        //
        // file cards
        //
        this.#file_items_scroll = new ScrollBox();
        this.actor.add_actor(this.#file_items_scroll.actor);
        for (const [idx, file] of applet.storage.read.files.value.entries()) {
            const card = new FileCard(this, applet, file, idx === 0);
            this.#file_items_scroll.box.add_actor(card.actor);
        }
        //
        // buttons
        //
        this.#button_box = new ButtonBox(this.actor);
        this.#button_ok = this.#button_box.add({ wide: true, label: _('Ok') });
        this.#button_add_file = this.#button_box.add({ wide: true, label: _('Add File') });
        //
        // listen
        //
        this.#button_add_file.subscribe('left_click', () => this.show_add_new_file());
        this.#button_ok.subscribe('left_click', () => this.#applet.load_tasks_from_file());
        //
        // finally
        //
        if (applet.storage.read.files.value.length === 0)
            this.show_add_new_file();
    }
    destroy() {
        this.actor.destroy();
    }
    show_add_new_file() {
        this.#button_box.actor.hide();
        this.#file_items_scroll.actor.hide();
        const picker = new FilePicker();
        this.actor.add_actor(picker.actor);
        const ok = new Button({ parent: this.actor, label: _('Ok') });
        ok.subscribe('left_click', () => {
            if (picker.path) {
                const file = new M.TodoFile();
                file.path = picker.path;
                const card = new FileCard(this, this.#applet, file);
                this.#file_items_scroll.box.add_actor(card.actor);
                this.#applet.storage.modify('files', v => v.value.push(file));
                this.select_file(file, ok.actor);
            }
            else {
                picker.actor.destroy();
                ok.actor.destroy();
                this.#button_box.actor.show();
                this.#file_items_scroll.actor.show();
            }
        });
    }
    select_file(file, error_popup_location) {
        if (!Fs.create_file(file.path)) {
            show_error_popup(error_popup_location, _('Could not create file.'));
            return;
        }
        this.#applet.storage.modify('files', ({ value }) => {
            const idx = value.indexOf(file);
            const tmp = value[0];
            value[0] = file;
            value[idx] = tmp;
        });
        this.#applet.load_tasks_from_file();
    }
    delete_file(file) {
        this.#applet.storage.modify('files', v => {
            const needs_load = (v.value[0] === file);
            array_remove(v.value, file);
            if (needs_load)
                this.#applet.load_tasks_from_file();
            else
                this.actor.destroy();
        });
    }
}
class FileCard extends Card {
    file;
    constructor(switcher, applet, file, checked = false) {
        super();
        this.file = file;
        const checkbox = new CheckBox({ parent: this.left_header_box, checked });
        const delete_button = new Button({ parent: this.autohide_box, icon: 'cronomix-trash-symbolic', style_class: 'cronomix-floating-button' });
        const file_picker = new FilePicker({ parent: this.actor, path: this.file.path });
        checkbox.subscribe('left_click', () => switcher.select_file(file, checkbox.actor));
        delete_button.subscribe('left_click', () => switcher.delete_file(file));
        file_picker.on_change = () => {
            if (file_picker.path) {
                this.file.path = file_picker.path;
                applet.storage.flush();
            }
        };
    }
}
