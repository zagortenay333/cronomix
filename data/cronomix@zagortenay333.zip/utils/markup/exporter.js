const _ME = imports.misc.extensionUtils.getCurrentExtension();

const { unreachable } = _ME.imports.utils.misc;
const P = _ME.imports.utils.markup.parser;
function markup_to_html(markup) {
    const parser = new P.Parser(markup);
    const ast = [...parser.parse_blocks()];
    return ast_to_html(markup, ast);
}
function ast_to_html(text, nodes) {
    let result = '';
    for (const node of nodes) {
        const indent = ' '.repeat(4 * node.indent);
        const children = P.get_children(node);
        switch (node.tag) {
            case 'AstMeta':
                {
                    if (node.config.image) {
                        const w = node.config.image.width;
                        const ws = (w !== undefined) ? `width="${w}"` : '';
                        result += indent + `<img src="${node.config.image.path}" alt="" ${ws}>\n`;
                    }
                    else if (node.config.admonition !== undefined) {
                        result += indent + `<div><p class="admonition-${node.config.admonition}"></p>` + ast_to_html(text, children) + indent + '</p></div>\n';
                    }
                    else {
                        result += ast_to_html(text, P.get_children(node));
                    }
                }
                break;
            case 'AstSeparator':
                result += '<hr>';
                break;
            case 'AstHeader':
                result += indent + `<h${node.size}>\n` + ast_to_html(text, children) + indent + `</h${node.size}>\n`;
                break;
            case 'AstListItem':
                result += indent + '<li>\n' + ast_to_html(text, children) + indent + '</li>\n';
                break;
            case 'AstList':
                result += indent + '<ul>\n' + ast_to_html(text, children) + indent + '</ul>\n';
                break;
            case 'AstOrderedList':
                result += indent + '<ol>\n' + ast_to_html(text, children) + indent + '</ol>\n';
                break;
            case 'AstRawBlock':
                result += indent + '<pre><code>\n' + ast_to_html(text, children) + indent + '</code></pre>\n';
                break;
            case 'AstParagraph':
                result += indent + '<p>\n' + ast_to_html(text, children) + indent + '</p>\n';
                break;
            case 'AstTableRow':
                result += indent + '<tr>\n' + ast_to_html(text, children) + indent + '</tr>\n';
                break;
            case 'AstTableCell':
                result += indent + '<td>\n' + ast_to_html(text, children) + indent + '<td>\n';
                break;
            case 'AstTable':
                result += indent + '<table>\n' + ast_to_html(text, children) + indent + '</table>\n';
                break;
            case 'AstSub':
                result += '<sub>' + ast_to_html(text, children) + '</sub>';
                break;
            case 'AstSup':
                result += '<sup>' + ast_to_html(text, children) + '</sup>';
                break;
            case 'AstStrike':
                result += '<del>' + ast_to_html(text, children) + '</del>';
                break;
            case 'AstBold':
                result += '<b>' + ast_to_html(text, children) + '</b>';
                break;
            case 'AstItalic':
                result += '<i>' + ast_to_html(text, children) + '</i>';
                break;
            case 'AstHighlight':
                result += '<em>' + ast_to_html(text, children) + '</em>';
                break;
            case 'AstRawInline':
                result += '<pre><code>' + ast_to_html(text, children) + '</pre><code>';
                break;
            case 'AstTagRef':
                result += '<b class="tag-ref">' + ast_to_html(text, children) + '</b class="tag-ref">';
                break;
            case 'AstFilterNot':
                result += '<code class="filter">' + ast_to_html(text, children) + '</code>';
                break;
            case 'AstFilterOr':
                result += '<code class="filter">' + ast_to_html(text, children) + '</code>';
                break;
            case 'AstFilterAnd':
                result += '<code class="filter">' + ast_to_html(text, children) + '</code>';
                break;
            case 'AstFilterAny':
                result += '<code class="filter">' + ast_to_html(text, children) + '</code>';
                break;
            case 'AstFilterDue':
                result += '<code class="filter">' + ast_to_html(text, children) + '</code>';
                break;
            case 'AstFilterDone':
                result += '<code class="filter">' + ast_to_html(text, children) + '</code>';
                break;
            case 'AstFilterPin':
                result += '<code class="filter">' + ast_to_html(text, children) + '</code>';
                break;
            case 'AstFilterHide':
                result += '<code class="filter">' + ast_to_html(text, children) + '</code>';
                break;
            case 'AstFilterTag':
                result += '<code class="filter">' + ast_to_html(text, children) + '</code>';
                break;
            case 'AstFilterFuzzy':
                result += '<code class="filter">' + ast_to_html(text, children) + '</code>';
                break;
            case 'AstFilterString':
                result += '<code class="filter">' + ast_to_html(text, children) + '</code>';
                break;
            case 'AstFilterPriority':
                result += '<code class="filter">' + ast_to_html(text, children) + '</code>';
                break;
            case 'AstText':
                result += text.substring(node.start, node.end);
                break;
            case 'AstLink':
                result += `<a href="${node.link}">` + (node.alias || node.link) + '</a>';
                break;
            case 'AstDummy': break;
            default: unreachable(node);
        }
    }
    return result;
}
