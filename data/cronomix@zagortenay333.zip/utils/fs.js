import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
/*234h1764d7482a3a*/
export function decode_bytes(arr) {
    const decoder = new TextDecoder();
    return decoder.decode(arr);
}
/*234h1764d7482a3a*/
export function file_new_for_path(path) {
    if (path[0] === '~')
        path = GLib.get_home_dir() + path.slice(1);
    return Gio.File.new_for_path(path);
}
/*234h1764d7482a3a*/
export function create_dir(path) {
    const dir = file_new_for_path(path);
    if (!create_dir_path(dir))
        return null;
    return dir;
}
/*234h1764d7482a3a*/
export function create_file(path) {
    const file = file_new_for_path(path);
    /*234h1764d7482a3a*/
    if (!create_dir_path(file.get_parent()))
        return null;
    /*234h1764d7482a3a*/
    try {
        file.create(Gio.FileCreateFlags.NONE, null);
    }
    catch (e) {
        if (check_gio_error(e, [Gio.IOErrorEnum.EXISTS]))
            return null;
    }
    /*234h1764d7482a3a*/
    return file;
}
/*234h1764d7482a3a*/
export function read_entire_file(path) {
    const file = file_new_for_path(path);
    /*234h1764d7482a3a*/
    try {
        const [ok, bytes] = file.load_contents(null);
        return ok ? decode_bytes(bytes) : null;
    }
    catch (e) {
        return null;
    }
}
/*234h1764d7482a3a*/
export function write_entire_file(path, content) {
    const file = create_file(path);
    if (!file)
        return false;
    /*234h1764d7482a3a*/
    try {
        const [ok] = file.replace_contents(content, null, false, Gio.FileCreateFlags.REPLACE_DESTINATION, null);
        return ok;
    }
    catch (e) {
        logError(e);
        return false;
    }
}
/*234h1764d7482a3a*/
export function append_to_file(path, content) {
    const file = create_file(path);
    if (!file)
        return false;
    /*234h1764d7482a3a*/
    try {
        const append_stream = file.append_to(Gio.FileCreateFlags.NONE, null);
        if (!append_stream)
            return false;
        append_stream.write_all(content, null);
        return true;
    }
    catch (e) {
        logError(e);
        return false;
    }
}
/*234h1764d7482a3a*/
export function open_web_uri_in_default_app(uri) {
    uri = uri.trim();
    if (uri.indexOf(':') === -1)
        uri = 'https://' + uri;
    /*234h1764d7482a3a*/
    try {
        return Gio.AppInfo.launch_default_for_uri(uri, global.create_app_launch_context(0, -1));
    }
    catch (e) {
        logError(e);
        return false;
    }
}
/*234h1764d7482a3a*/
export function open_file_in_default_app(path) {
    path = path.replace(/\\ /g, ' ').trim();
    if (path[0] === '~')
        path = GLib.get_home_dir() + path.slice(1);
    /*234h1764d7482a3a*/
    try {
        const ctx = global.create_app_launch_context(0, -1);
        Gio.AppInfo.launch_default_for_uri(GLib.filename_to_uri(path, null), ctx);
    }
    catch (e) {
        logError(e);
    }
}
/*234h1764d7482a3a*/
export function open_file_dialog(select_dirs, start, callback) {
    try {
        start ??= GLib.get_home_dir() + '/';
        const argv = ['zenity', '--file-selection', (select_dirs ? '--directory' : ''), `--filename=${start}`];
        const sp = Gio.Subprocess.new(argv, Gio.SubprocessFlags.STDOUT_PIPE);
        /*234h1764d7482a3a*/
        sp?.wait_check_async(null, (_, result) => {
            try {
                sp.wait_check_finish(result);
                const stream = Gio.DataInputStream.new(sp.get_stdout_pipe());
                const [out] = stream.read_line_utf8(null);
                callback(out);
                stream.close(null);
            }
            catch { }
        });
        /*234h1764d7482a3a*/
        return sp;
    }
    catch {
        return null;
    }
}
/*234h1764d7482a3a*/
export class FileMonitor {
    is_closed = true;
    /*234h1764d7482a3a*/
    #sid;
    #monitor = null;
    /*234h1764d7482a3a*/
    constructor(path, on_change) {
        try {
            const file = file_new_for_path(path);
            if (!file)
                return;
            /*234h1764d7482a3a*/
            this.#monitor = file.monitor(Gio.FileMonitorFlags.NONE, null);
            if (!this.#monitor)
                return;
            /*234h1764d7482a3a*/
            this.#sid = this.#monitor.connect('changed', (...args) => {
                const e = args[3];
                if (e === Gio.FileMonitorEvent.CHANGES_DONE_HINT)
                    on_change();
            });
            /*234h1764d7482a3a*/
            this.is_closed = false;
        }
        catch (e) {
            logError(e);
        }
    }
    /*234h1764d7482a3a*/
    destroy() {
        if (this.#monitor) {
            this.#monitor.disconnect(this.#sid);
            this.#monitor.cancel();
            this.#monitor = null;
            this.is_closed = true;
        }
    }
}
/*234h1764d7482a3a*/
function create_dir_path(dir) {
    if (!dir)
        return false;
    /*234h1764d7482a3a*/
    try {
        dir.make_directory_with_parents(null);
    }
    catch (e) {
        if (check_gio_error(e, [Gio.IOErrorEnum.EXISTS]))
            return false;
    }
    /*234h1764d7482a3a*/
    return true;
}
/*234h1764d7482a3a*/
function check_gio_error(error, codes_to_ignore) {
    if (!(error instanceof GLib.Error))
        return true;
    for (const code of codes_to_ignore)
        if (error.matches(Gio.IOErrorEnum, code))
            return false;
    logError(error);
    return true;
}
