import * as Misc from './misc.js';
/*234h1764d7482a3a*/
export class PubSub {
    #next_id = 1;
    #handlers = new Map();
    #id_map = new Map();
    /*234h1764d7482a3a*/
    publish(event, msg) {
        const list = this.#handlers.get(event) ?? [];
        for (const handler of list)
            handler(msg);
    }
    /*234h1764d7482a3a*/
    subscribe(event, handler) {
        if (this.#next_id === Number.MAX_SAFE_INTEGER)
            return 0;
        /*234h1764d7482a3a*/
        const list = this.#handlers.get(event) ?? [];
        list.push(handler);
        this.#handlers.set(event, list);
        /*234h1764d7482a3a*/
        const id = this.#next_id++;
        this.#id_map.set(id, { event, handler });
        return id;
    }
    /*234h1764d7482a3a*/
    unsubscribe(id) {
        const handler = this.#id_map.get(id);
        if (!handler)
            return;
        this.#id_map.delete(id);
        /*234h1764d7482a3a*/
        const list = this.#handlers.get(handler.event);
        Misc.array_remove(list, handler.handler);
    }
    /*234h1764d7482a3a*/
    unsubscribe_all() {
        this.#next_id = 1;
        this.#id_map.clear();
        this.#handlers.clear();
    }
}
