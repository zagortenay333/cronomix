const _ME = imports.misc.extensionUtils.getCurrentExtension();

const St = imports.gi.St;
const Clutter = imports.gi.Clutter;
const { Tracker } = _ME.imports.utils.tracker;
const { scroll_to_widget } = _ME.imports.utils.scroll;
var Card = class Card {
    actor;
    header;
    left_header_box;
    autohide_box;
    contains_focused_actor = false;
    constructor() {
        this.actor = new St.BoxLayout({ reactive: true, vertical: true, x_expand: true, style_class: 'cronomix-card cronomix-box' });
        this.header = new St.BoxLayout({ y_align: Clutter.ActorAlign.CENTER, style_class: 'header' });
        this.actor.add_actor(this.header);
        this.left_header_box = new St.BoxLayout({ reactive: true, x_expand: true });
        this.header.add_actor(this.left_header_box);
        this.autohide_box = new St.BoxLayout({ visible: false });
        this.header.add_actor(this.autohide_box);
        const tracker = new Tracker(this.actor);
        tracker.subscribe('focus_enter', () => { scroll_to_widget(this.actor); this.autohide_box.show(); });
        tracker.subscribe('focus_leave', (has_pointer) => this.autohide_box.visible = has_pointer);
        tracker.subscribe('pointer_enter', () => this.autohide_box.show());
        tracker.subscribe('pointer_leave', (has_focus) => this.autohide_box.visible = has_focus);
    }
}
