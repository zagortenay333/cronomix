Sound files picked from the following websites:

  - http://www.bigsoundbank.com/
  - http://soundbible.com/royalty-free-sounds-1.html
